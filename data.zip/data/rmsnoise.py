#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  5 15:40:41 2024

@author: calvino
"""
# RMS nosie vs update rate(Hz)
import numpy as np
import matplotlib.pyplot as plt

# sample frequency (Hz)
frequencies = [
    4.17, 10, 20, 50, 100, 200, 300, 400, 500
    
]

# RMS nosie
rms_noise = [
    2.8734869e-5, 3.2, 2.5, 1.8, 1.5, 1.3, 1.2, 1.1, 1.0
    
]

# 拟合理论曲线 (假设模型为 y = a / sqrt(x) + b)
def theoretical_model(x, a, b):
    return a / np.sqrt(x) + b

# 使用scipy curve_fit来拟合理论曲线
from scipy.optimize import curve_fit

# 初始猜测参数
initial_guess = [1, 1]
params, covariance = curve_fit(theoretical_model, frequencies, rms_noise, p0=initial_guess)

# 创建用于绘制理论曲线的频率范围
freq_range = np.linspace(min(frequencies), max(frequencies), 500)
theoretical_noise = theoretical_model(freq_range, *params)

# 创建图表
plt.figure(figsize=(10, 6))
plt.plot(frequencies, rms_noise, 'o', label='Measured RMS Noise', color='b')
plt.plot(freq_range, theoretical_noise, '-', label='Theoretical RMS Noise', color='r')

# 添加标题和标签
plt.title('RMS Noise vs Sampling Frequency for AD7793')
plt.xlabel('Sampling Frequency (Hz)')
plt.ylabel('RMS Noise')
plt.legend()

# 显示网格
plt.grid(True)

# 显示图表
plt.show()
