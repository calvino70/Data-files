#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 16:10:53 2024

@author: calvino
"""

import pandas as pd
import matplotlib.pyplot as plt

file_path = 'test.xlsx'
data = pd.read_excel(file_path)

print(data.head())

plt.figure(figsize=(10, 6))
plt.plot(data['set voltage(V)'], data['ad7793(V)'], marker='o', linestyle='-', color='b')
plt.title('Set Voltage vs AD7793 Voltage')
plt.xlabel('Set Voltage (V)')
plt.ylabel('AD7793 Voltage (V)')
plt.grid(True)
plt.show()

# 绘制设定电压与示波器观测值
plt.figure(figsize=(10, 6))
plt.plot(data['Set Voltage'], data['oscilloscope(V)'], marker='s', linestyle='--', color='r')
plt.title('Set Voltage vs Oscilloscope Voltage')
plt.xlabel('Set Voltage (V)')
plt.ylabel('Oscilloscope Voltage (V)')
plt.grid(True)
plt.show()
